import random
import json
dash = "-------------------------------------------------------------------"
my_char = {}

def classList():
    listnum = 1
    print(dash)
    print("Here is a list of all the availible classes, please make your choice!")
    clist = ["Artificer", "Barbarian", "Bard", "Cleric", "Druid", "Fighter", "Monk", "Paladin", "Ranger", "Rogue", 
             "Sorcerer", "Warlock", "Wizard"]
    for i in clist:
        print(str(listnum) + '.)',i)
        listnum = listnum + 1
    print(dash)
    return clist

def raceList():
    listnum = 1
    print(dash)
    print("Here is a list of all the availible races, please make your choice!")
    rlist= ["Human", "Half-Elf", "Half-Orc", "Halfling", "Dwarf", "Dragonborn", "Tiefling", "Gnome"]
    for i in rlist:
        print(str(listnum) + '.)',i)
        listnum = listnum + 1
    print(dash)
    return rlist

def classStat():
    # Order of stat values: Strength, Dexterity, Intelligence, Wisdom, Charisma, Constitution
    classStats = {"Artificer": {"int": 2, "con": 1}, 
                  "Barbarian": {"str": 2, "con": 1}, 
                  "Bard": {"chr": 2, "dex": 1}, 
                  "Cleric": {"wis": 2, "str": 1}, 
                  "Druid": {"wis": 2, "dex": 1}, 
                  "Fighter": {"dex": 2, "str": 1}, 
                  "Monk": {"dex": 2, "wis": 1}, 
                  "Paladin": {"chr": 2, "str": 1}, 
                  "Ranger": {"dex": 2, "wis": 1}, 
                  "Rogue": {"dex": 2, "chr": 1}, 
                  "Sorcerer": {"int": 2, "dex": 1}, 
                  "Warlock": {"chr": 2, "int": 1}, 
                  "Wizard": {"int": 2, "wis": 1}}
    return classStats

print("Welcome to the DnD Character Creator!")
charName = str(input("To start, lets give you a name: "))

classType = ""
clist = classList()
while classType not in clist:
    classType = str(input("Now that you have seen the list, please choose a class: "))
    if classType not in clist:
        print("That was not a valid class option, please try again.")

raceType = ""
rlist = raceList()
while raceType not in rlist:
    raceType = str(input("Now that you have seen the list, please choose a race: "))
    if raceType not in rlist:
        print("That was not a valid race option, please try again.")

print(dash)
charStat = {"Strength": random.randint(8,17),
            "Dexterity": random.randint(8,17),
            "Intelligence": random.randint(8,17),
            "Wisdom": random.randint(8,17),
            "Charisma": random.randint(8,17),
            "Constitution": random.randint(8,17)}
for i in charStat:
    print(i, charStat[i])
print(dash)

statChange = ""
statChange = str(input("Would you like to reroll: "))
if (statChange == "yes" or statChange == "Yes"):
    charStat["Strength"] = random.randint(8,17)
    charStat["Dexterity"] = random.randint(8,17)
    charStat["Intelligence"] = random.randint(8,17)
    charStat["Wisdom"] = random.randint(8,17)
    charStat["Charisma"] = random.randint(8,17)
    charStat["Constitution"] = random.randint(8,17)
else:
    print("You chose to keep your stats!")

classStat = classStat()
if classType in classStat:
    modifier = classStat[classType]
    for i in modifier:
        if (i == "str"):
            charStat["Strength"] += modifier["str"]
        elif (i == "dex"):
            charStat["Dexterity"] += modifier["dex"]
        elif (i == "int"):
            charStat["Intelligence"] += modifier["int"]
        elif (i == "wis"):
            charStat["Wisdom"] += modifier["wis"]
        elif (i == "chr"):
            charStat["Charisma"] += modifier["chr"]
        elif (i == "con"):
            charStat["Constitution"] += modifier["con"]
        else:
            print("Fuck you")

print(dash)
print("Now we officially have your basic info:")
print(dash)
print("Name:",charName)
print(dash)
print("Race:",raceType)
print(dash)
print("Class:",classType)
print(dash)
for i in charStat:
    print(i, charStat[i])
print(dash)

equipment = {}
spells = {}
gold = {}
statCheck = {}

for s in charStat:
    answer = (charStat[s] - 10)/2
    statCheck[s] = int(answer)

my_char['Name'] = charName
my_char['Race'] = raceType
my_char['Class'] = classType
my_char['Stats'] = charStat
my_char['Equipment'] = equipment
my_char['Spells'] = spells
my_char['Gold'] = gold
my_char['statCheck'] = statCheck



with open('char.json', 'w') as char_file:
    json.dump(my_char, char_file, indent=4)

