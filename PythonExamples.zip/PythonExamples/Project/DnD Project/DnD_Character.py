import random
dash = "-------------------------------------------------------------------"

def classList():
    listnum = 1
    print(dash)
    print("Here is a list of all the availible class, please make your choice!")
    clist = ["Artificer", "Barbarian", "Bard", "Cleric", "Druid", "Fighter", "Monk", "Paladin", "Ranger", "Rogue", "Sorcerer", "Warlock", "Wizard"]
    for i in clist:
        print(str(listnum) + '.)',i)
        listnum = listnum + 1
    print(dash)
    return clist

def stats():
    charStat = {"Strength": random.randint(8,17),
                "Dexterity": random.randint(8,17),
                "Intelligence": random.randint(8,17),
                "Wisdom": random.randint(8,17),
                "Charisma": random.randint(8,17)}
    for i in charStat:
         print(i, charStat[i])



print("Welcome to the DnD Character Creator!")
charName = str(input("To start, lets give you a name: "))

classType = ""
clist = classList()
while classType not in clist:
    classType = str(input("Now that you have seen the list, please choose a class: "))
    if classType not in clist:
        print("That was not a valid class option, please try again.")

print(dash)
statChange = ""
charStats = stats()
print(dash)
while statChange not in charStats:
    statChange = str(input("Please choose the stat you'd like to change: "))
    if statChange not in charStats:
        print("Please choose another stat. The one you chose was not valid.")


