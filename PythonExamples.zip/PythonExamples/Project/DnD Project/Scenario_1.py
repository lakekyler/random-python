import json 
import random
from colorama import init, Fore, Style
init()
dash = f"{Fore.LIGHTYELLOW_EX}----------------------------------------------------------------------{Style.RESET_ALL}"

with open('char.json', 'r') as char:
    mychar = json.load(char)


print("Welcome to 'The Whispering Orchid'", mychar['Name'] + ".")
print("In this beginner-level encounter, you will dive into the curious case\n" \
"of Oakhaven's dwindling autumn harvest.It will be your mission to investigate\n"
"and help the people of Oakhaven to guarantee their survival in the winter.")
print(dash)
while True:
    con = input("Are you ready to take on this mission?[Yes|No] ").lower().strip()
    if con == 'yes':
        print("You said 'Yes'. Lets begin your journey!")
        break
    elif con == 'no':
        print("You said 'No'. The town of Oakhaven hopes for your return")
        exit()
    else:
        print("Invalid input. Please enter 'yes' or 'no'.")
    True

print()
print(dash)
print()
print("It is a cool October afternoon. The autumn leaves are blowing in the\n" \
"chilling wind as you stroll down the narrow dirt road to Oakhaven.")
print()
print("You have heard stories of the towns magical autumn festivals, full\n" \
"of music and food from all across the valley.However, these stories\n" \
"of the legendary Oakhaven seem vastly different to the sight before you.")
print()
print("Upon coming into view, Oakhaven ressembled the like of a ghost town.\n" \
"Not a living thing in sight...shutters to houses and shops closed.\n" \
"The only sign of life seemed to be coming from the (supposedly) the tavern...")
print()
print("Lost in your own thoughts of disappointment, you accidentally\n" \
"bump into a cloaked figure. They seemed frail, shorter than you are\n" \
"and made squeal-like sound on contact. They remove their hood and you see\n" \
"an emaciated-looking man that could have been mistakened for\n" \
"a boy had it not been for the subtle smell of beer and the eyes of\n" \
"a recent hangover.")
print()
print(f"{Fore.LIGHTYELLOW_EX}--------------------------- Encounter 1 --------------------------------{Style.RESET_ALL}")
print()
print(f"{Fore.MAGENTA}'HEY!' He winced\n{Style.RESET_ALL}" \
      f"{Fore.MAGENTA}'Watch where you're going dumbass!'{Style.RESET_ALL}")
print()
while True:
    ans1 = input(" After looking at the man's appearance...you decide to [Walk Away|Talk to Him]: ").lower().strip()
    print()
    print(dash)
    print()
    if ans1 == 'walk away':
        print("You chose to 'Walk Away'. Ignoring his desperate pleas, you continue\n" \
        "down the road to Oakhaven.")
        break
    elif ans1 == 'talk to him':
        print("You decided to help the man up to his feet, handing him his bag\n" \
        "before continuing to talk to him.")
        print()
        print("'Ahem...thank you' he says as he brushes off his cloak\n" \
        "'For your kindness, I offer you this fine weapon!'")
        print()
        print("He pull out what appears to be a Jambiya, easily identifiable\n" \
        "by its hooked blade 'I can sell it to you for a reasonable price. 75 gold\n" \
        "...more than half of what I bought it for!'")
        print()
        print(dash)
        print()
        print("Going through your pockets, you soon realize that the fun that occurred the night before may have been a bit too much for your wallet.")
        ans2 = input("Knowing that you are penniless, what do you do next [Persuade, Decline, Steal, Bargain, Intimidate]: ").lower().strip()
        print()
        print(dash)
        print()
        if ans2 == 'persuade':
            cloakedChr = 16
            if cloakedChr <= (int(mychar['statCheck']['Charisma']) + random.randint(1, 20)):
                print(f"{Fore.GREEN}You persuade the slightly drunken man to give you the dagger for free!{Style.RESET_ALL}")
                print(f"{Fore.LIGHTCYAN_EX}You have now obtained a [Mythril Jambiya]{Style.RESET_ALL}")
                mychar['Equipment'] = 'Mythril Jambiya'
            else:
                print(f"{Fore.RED}The man scoffs at you and spits at your 'poor' feet. You both part ways and\n{Style.RESET_ALL}" \
                f"{Fore.RED}you continue down the path to Oakhaven.{Style.RESET_ALL}")
        elif ans2 == 'decline':
            print(f"{Fore.GREEN}You reluctantly decline his offer and continue down the path to Oakhaven.{Style.RESET_ALL}")
        elif ans2 == 'steal':
            cloakedDex = 10
            if cloakedDex <= (int(mychar['statCheck']['Dexterity']) + random.randint(1, 20)):
                print(f"{Fore.GREEN}You yank the dagger out of the cloaked mans hands and run into the woods.\n{Style.RESET_ALL}" \
                f"{Fore.GREEN}After the cloaked man gave up on his measily attempt to pursue you, you make your way\n{Style.RESET_ALL}" \
                f"{Fore.GREEN}back to the path and make your way to Oakhaven.{Style.RESET_ALL}")
                print(f"{Fore.LIGHTCYAN_EX}You have now obtained a [Mythril Jambiya]{Style.RESET_ALL}")
                mychar['Equipment'] = 'Mythril Jambiya'
            else:
                print(f"{Fore.RED}Your measily attempt to snatch it from him was all in vain. He keeps his distance\n{Style.RESET_ALL}" \
                f"{Fore.RED}and watches you stumble to the ground. He laughs as he walks away and after recovering\n{Style.RESET_ALL}" \
                f"{Fore.RED}from the embaressment, you make your way to Oakhaven.{Style.RESET_ALL}")
        elif ans2 == 'intimidate':
            cloakedChr = 8
            if cloakedChr <= (int(mychar['statCheck']['Strength']) + random.randint(1, 20)):
                print(f"{Fore.GREEN}You size up on the frail man and snatch the dagger from his hands, he attempts\n{Style.RESET_ALL}" \
                f"{Fore.GREEN}to plea for it back but ran away after you threaten to punch in his skull. you secure\n{Style.RESET_ALL}" \
                f"{Fore.GREEN}your newly owned dagger to your belt and continue to Oakhaven.{Style.RESET_ALL}")
                print(f"{Fore.LIGHTCYAN_EX}You have now obtained a [Mythril Jambiya]{Style.RESET_ALL}")
                mychar['Equipment'] = 'Mythril Jambiya'
            else:
                print(f"{Fore.RED}Your attempt to intimidate the man was in vain as he laughs at you for the ambition.\n{Style.RESET_ALL}" \
                f"{Fore.RED}you attempt to attack but he shoves you to the ground and kicks you in the stomach. After he\n{Style.RESET_ALL}" \
                f"{Fore.RED}walks away you stand up and limp your way into Oakhaven.{Style.RESET_ALL}")
        elif ans2 == 'bargain':
            cloakedChr = 12
            if cloakedChr <= (int(mychar['statCheck']['Charisma']) + random.randint(1, 20)):
                print(f"{Fore.GREEN}You bargain with the cloaked man and he agrees to give you the dagger in exchange for.\n{Style.RESET_ALL}" \
                f"{Fore.GREEN}paying for a new set of ink and quill when he comes back into town. A drunk man can't have hobbies?{Style.RESET_ALL}")
                print(f"{Fore.LIGHTCYAN_EX}you have now obtained a [Mythril Jambiya]{Style.RESET_ALL}")
                mychar['Equipment'] = 'Mythril Jambiya'
            else:
                print(f"{Fore.RED}He bursts into an insane attempt to bargain with him. He rudely declines you bargain and continues\n{Style.RESET_ALL}" \
                f"{Fore.RED}to laugh as he walks away. You make your way to Oakhaven in defeat.{Style.RESET_ALL}")
        else:
            print("you have entered an invalid option, please try again.")
        break
    else:
        print("Invalid input. Please enter 'Walk Away' or 'Talk to Him'.")
    True

print()
print("--------------------------- Encounter 2 --------------------------------")